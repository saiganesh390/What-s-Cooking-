package com.cookingrecipe;
import com.cookingrecipe.model.User;
 
 
import com.cookingrecipe.model.UserRole;
import com.cookingrecipe.repository.UserRepository;
import com.cookingrecipe.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@Transactional
public class UserServiceTest {
    @Autowired
    private UserService userService;
    @Autowired
    private UserRepository userRepository;
    private User testUser;
    @BeforeEach
    public void setUp() {
        // Clear repository before each test
        userRepository.deleteAll();
        // Create and save a test user
        testUser = new User();
        testUser.setEmail("testuser@example.com");
        testUser.setPassword("password123"); // In real scenarios, use hashed passwords
        testUser.setRole(UserRole.USER);
        userRepository.save(testUser);
    }
    @Test
    public void testRegisterUser() {
        User newUser = new User();
        newUser.setEmail("newuser@example.com");
        newUser.setPassword("newpassword123");
        User registeredUser = userService.registerUser(newUser);
        assertNotNull(registeredUser);
        assertEquals("newuser@example.com", registeredUser.getEmail());
        assertEquals(UserRole.USER, registeredUser.getRole());
    }
//    @Test
//    public void testFindByEmail() {
//        User foundUser = userService.findByEmail("testuser@example.com");
//        assertNotNull(foundUser);
//        assertEquals("testuser@example.com", foundUser.getEmail());
//    }
    @Test
    public void testAuthenticateUserSuccess() {
        User authenticatedUser = userService.authenticateUser("testuser@example.com", "password123", UserRole.USER);
        assertNotNull(authenticatedUser);
        assertEquals("testuser@example.com", authenticatedUser.getEmail());
    }
    @Test
    public void testAuthenticateUserFailureWrongPassword() {
        assertThrows(IllegalArgumentException.class, () -> {
            userService.authenticateUser("testuser@example.com", "wrongpassword", UserRole.USER);
        });
    }
    @Test
    public void testAuthenticateUserFailureWrongRole() {
        assertThrows(IllegalArgumentException.class, () -> {
            userService.authenticateUser("testuser@example.com", "password123", UserRole.ADMIN);
        });
    }
    @Test
    public void testAuthenticateAdminSuccess() {
        testUser.setRole(UserRole.ADMIN);
        userRepository.save(testUser);
        User authenticatedUser = userService.authenticateAdmin("testuser@example.com", "password123");
        assertNotNull(authenticatedUser);
        assertEquals("testuser@example.com", authenticatedUser.getEmail());
    }
    @Test
    public void testAuthenticateAdminFailureWrongRole() {
        assertThrows(IllegalArgumentException.class, () -> {
            userService.authenticateAdmin("testuser@example.com", "password123");
        });
    }
    @Test
    public void testAuthenticateAdminFailureWrongPassword() {
        testUser.setRole(UserRole.ADMIN);
        userRepository.save(testUser);
        assertThrows(IllegalArgumentException.class, () -> {
            userService.authenticateAdmin("testuser@example.com", "wrongpassword");
        });
    }
}