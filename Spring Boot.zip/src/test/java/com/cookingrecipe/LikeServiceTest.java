package com.cookingrecipe;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
 
import com.cookingrecipe.model.Like;
import com.cookingrecipe.model.Recipe;
import com.cookingrecipe.model.User;
import com.cookingrecipe.model.UserRole;
import com.cookingrecipe.repository.LikeRepository;
import com.cookingrecipe.repository.RecipeRepository; // Assuming you have a Recipe repository
import com.cookingrecipe.repository.UserRepository;
import com.cookingrecipe.service.LikeService;
 
@SpringBootTest
@Transactional
public class LikeServiceTest {
 
    @Autowired
    private LikeService likeService;
 
    @Autowired
    private LikeRepository likeRepository;
 
    @Autowired
    private UserRepository userRepository;
 
    @Autowired
    private RecipeRepository recipeRepository; // Autowire the Recipe repository
 
    private User testUser;
    private Recipe testRecipe;
    private Like testLike;
 
    @BeforeEach
    public void setUp() {
        userRepository.deleteAll();
        likeRepository.deleteAll();
        recipeRepository.deleteAll(); // Ensure recipes are also cleared
 
        testUser = new User();
        testUser.setEmail("testuser@example.com");
        testUser.setPassword("password123");
        testUser.setRole(UserRole.USER);
        userRepository.save(testUser);
 
        testRecipe = new Recipe();
        testRecipe.setName("Test Recipe"); // Set required fields for Recipe
        recipeRepository.save(testRecipe);
 
        testLike = new Like();
        testLike.setUser(testUser);
        testLike.setRecipe(testRecipe); // Use the recipe object
        likeRepository.save(testLike);
    }
 
    @Test
    public void testSaveLike() {
        Like newLike = new Like();
        newLike.setUser(testUser);
        newLike.setRecipe(testRecipe); // Use the recipe object
 
        Like savedLike = likeService.saveLike(newLike);
        assertNotNull(savedLike);
        assertEquals(newLike.getRecipe().getId(), savedLike.getRecipe().getId());
    }
}