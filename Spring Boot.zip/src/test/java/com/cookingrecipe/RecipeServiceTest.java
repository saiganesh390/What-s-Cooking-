package com.cookingrecipe;
 
import com.cookingrecipe.model.Recipe;
import com.cookingrecipe.repository.RecipeRepository;
import com.cookingrecipe.service.RecipeService;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
 
import java.util.List;
import java.util.Optional;
 
import static org.junit.jupiter.api.Assertions.*;
 
@SpringBootTest
@Transactional
public class RecipeServiceTest {
 
    @Autowired
    private RecipeService recipeService; // Assume RecipeService is the interface
 
    @Autowired
    private RecipeRepository recipeRepository;
 
    @BeforeEach
    void setUp() {
        recipeRepository.deleteAll();
    }
 
    @Test
    void testGetAllRecipes() {
        // Setup
        Recipe recipe = new Recipe();
        recipe.setName("Test Recipe");
        recipeRepository.save(recipe);
 
        // Execute
        List<Recipe> recipes = recipeService.getAllRecipes();
 
        // Verify
        assertNotNull(recipes);
        assertEquals(1, recipes.size());
        assertEquals("Test Recipe", recipes.get(0).getName());
    }
 
    @Test
    void testGetRecipeByIdFound() {
        // Setup
        Recipe recipe = new Recipe();
        recipe.setName("Test Recipe");
        recipe = recipeRepository.save(recipe);
 
        // Execute
        Optional<Recipe> foundRecipe = recipeService.getRecipeById(recipe.getId());
 
        // Verify
        assertTrue(foundRecipe.isPresent());
        assertEquals("Test Recipe", foundRecipe.get().getName());
    }
 
    @Test
    void testGetRecipeByIdNotFound() {
        // Execute
        Optional<Recipe> foundRecipe = recipeService.getRecipeById(999L);
 
        // Verify
        assertFalse(foundRecipe.isPresent());
    }
 
    @Test
    void testCreateRecipe() {
        // Setup
        Recipe recipe = new Recipe();
        recipe.setName("New Recipe");
 
        // Execute
        Recipe savedRecipe = recipeService.createRecipe(recipe);
 
        // Verify
        assertNotNull(savedRecipe);
        assertNotNull(savedRecipe.getId());
        assertEquals("New Recipe", savedRecipe.getName());
    }
 
    @Test
    void testUpdateRecipe() {
        // Setup
        Recipe recipe = new Recipe();
        recipe.setName("Original Recipe");
        recipe = recipeRepository.save(recipe);
 
        // Modify recipe
        recipe.setName("Updated Recipe");
 
        // Execute
        Recipe updatedRecipe = recipeService.updateRecipe(recipe.getId(), recipe);
 
        // Verify
        assertNotNull(updatedRecipe);
        assertEquals("Updated Recipe", updatedRecipe.getName());
    }
 
    @Test
    void testUpdateRecipeNotFound() {
        // Setup
        Recipe recipe = new Recipe();
        recipe.setId(999L); // Non-existent ID
        recipe.setName("Non-existent Recipe");
 
        // Execute & Verify
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            recipeService.updateRecipe(recipe.getId(), recipe);
        });
        assertEquals("Recipe not found with id 999", exception.getMessage());
    }
 
    @Test
    void testDeleteRecipe() {
        // Setup
        Recipe recipe = new Recipe();
        recipe.setName("Test Recipe");
        recipe = recipeRepository.save(recipe);
 
        // Execute
        recipeService.deleteRecipe(recipe.getId());
 
        // Verify
        assertFalse(recipeRepository.findById(recipe.getId()).isPresent());
    }
 
    @Test
    void testDeleteRecipeNotFound() {
        // Execute & Verify
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            recipeService.deleteRecipe(999L); // Non-existent ID
        });
        assertEquals("Recipe not found with id 999", exception.getMessage());
    }
 
    @Test
    void testFindById() {
        // Setup
        Recipe recipe = new Recipe();
        recipe.setName("Test Recipe");
        recipe = recipeRepository.save(recipe);
 
        // Execute
        Recipe foundRecipe = recipeService.findById(recipe.getId());
 
        // Verify
        assertNotNull(foundRecipe);
        assertEquals(recipe.getId(), foundRecipe.getId());
        assertEquals("Test Recipe", foundRecipe.getName());
    }
}