package com.cookingrecipe;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
 
import com.cookingrecipe.model.Comment;
import com.cookingrecipe.model.Recipe;
import com.cookingrecipe.model.User;
import com.cookingrecipe.model.UserRole;
import com.cookingrecipe.repository.CommentRepository;
import com.cookingrecipe.repository.RecipeRepository;
import com.cookingrecipe.repository.UserRepository;
import com.cookingrecipe.service.CommentService;
 
@SpringBootTest
@Transactional
public class CommentServiceTest {
 
    @Autowired
    private CommentService commentService;
 
    @Autowired
    private CommentRepository commentRepository;
 
    @Autowired
    private UserRepository userRepository;
 
    @Autowired
    private RecipeRepository recipeRepository;
 
    private User testUser;
    private Recipe testRecipe;
 
    @BeforeEach
    public void setUp() {
        userRepository.deleteAll();
        commentRepository.deleteAll();
        recipeRepository.deleteAll();
 
        // Setting up test user
        testUser = new User();
        testUser.setEmail("testuser@example.com");
        testUser.setPassword("password123");
        testUser.setRole(UserRole.USER);
        userRepository.save(testUser);
 
        // Setting up test recipe
        testRecipe = new Recipe();
        testRecipe.setName("Test Recipe");
        // Add any other required fields for Recipe
        recipeRepository.save(testRecipe);
    }
 
    @Test
    public void testSaveComment() {
        // Creating a new comment
        Comment newComment = new Comment();
        newComment.setUser(testUser);
        newComment.setRecipe(testRecipe);
        newComment.setComment("This is a test comment.");
 
        // Saving the comment
        Comment savedComment = commentService.saveComment(newComment);
 
        // Assertions
        assertNotNull(savedComment);
        assertEquals(newComment.getComment(), savedComment.getComment());
        assertEquals(testUser.getId(), savedComment.getUser().getId());
        assertEquals(testRecipe.getId(), savedComment.getRecipe().getId());
        assertNotNull(savedComment.getCreatedAt()); // Check if the createdAt is set
    }
}