package com.cookingrecipe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cookingrecipe.model.AdminLoginRequest;
import com.cookingrecipe.model.UpdatePasswordRequest;
import com.cookingrecipe.model.User;
import com.cookingrecipe.model.UserLoginRequest;
import com.cookingrecipe.model.UserRole;
import com.cookingrecipe.service.UserService;

@RestController
@RequestMapping("/api/accounts") // Changed from /api/users

public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {
            // Register user with default role if not specified
            User registeredUser = userService.registerUser(user);
            return ResponseEntity.ok(registeredUser);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed. Please try again.");
        }
    }

    @GetMapping("/find")
    public ResponseEntity<List<User>> findByName(@RequestParam String name) {
        List<User> users = userService.findByName(name);
        return ResponseEntity.ok(users);
    }



    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody UserLoginRequest request) {
        try {
            // Call authenticateUser with the expected role
            User authenticatedUser = userService.authenticateUser(request.getEmail(), request.getPassword(), UserRole.USER);
            return ResponseEntity.ok(authenticatedUser);
        } catch (IllegalArgumentException e) {
            // Return unauthorized status and error message
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }

    @PostMapping("/admin/login")
    public ResponseEntity<?> adminLogin(@RequestBody AdminLoginRequest request) {
        try {
            // Authenticate the user
            User user = userService.authenticateAdmin(request.getEmail(), request.getPassword());
            return ResponseEntity.ok(user);
        } catch (IllegalArgumentException e) {
            // Return unauthorized status and error message
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }
    
    @PostMapping("/register/admin")
    public ResponseEntity<?> registerAdmin(@RequestBody User user) {
        try {
            // Set the role to ADMIN
            user.setRole(UserRole.ADMIN);
            
            // Call the service to save the user
            User registeredAdmin = userService.registerAdmin(user);
            return ResponseEntity.status(HttpStatus.CREATED).body(registeredAdmin);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Admin registration failed. Please try again.");
        }
    }
    @PutMapping("/update-password")
    public ResponseEntity<String> updatePassword(@RequestBody UpdatePasswordRequest request) {
        // Check if new password matches confirmation
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            return ResponseEntity.badRequest().body("Passwords do not match.");
        }

        // Update password using the service based on email
        boolean updated = userService.updatePasswordByEmail(request.getEmail(), request.getNewPassword());
        if (!updated) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
        }

        return ResponseEntity.ok("Password updated successfully.");
    }




}
