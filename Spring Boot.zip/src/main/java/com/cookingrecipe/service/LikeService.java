package com.cookingrecipe.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cookingrecipe.model.Like;
import com.cookingrecipe.model.Recipe;
import com.cookingrecipe.model.User;
import com.cookingrecipe.repository.LikeRepository;
import com.cookingrecipe.repository.RecipeRepository;
import com.cookingrecipe.repository.UserRepository;

@Service
public class LikeService {
    @Autowired
    private LikeRepository likeRepository;

    @Autowired
    private RecipeRepository recipeRepository;

    @Autowired
    private UserRepository userRepository;

    public Like saveLike(Like like) {
        Recipe recipe = recipeRepository.findById(like.getRecipe().getId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid recipe ID"));
        User user = userRepository.findById(like.getUser().getId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID"));
        like.setRecipe(recipe);
        like.setUser(user);
        return likeRepository.save(like);
    }
}
