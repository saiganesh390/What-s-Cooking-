package com.cookingrecipe.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cookingrecipe.model.User;
import com.cookingrecipe.model.UserRole;
import com.cookingrecipe.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    

    public User registerUser(User user) {
        // Set default role for new users if not provided
        if (user.getRole() == null) {
            user.setRole(UserRole.USER); // Default to USER
        }
        return userRepository.save(user);
    }


    public boolean updatePasswordByEmail(String email, String newPassword) {
        User user = userRepository.findByEmail(email); // Ensure this method exists in your repository
        if (user == null) {
            return false; // User not found
        }

        // Update the password in the user object
        user.setPassword(newPassword); // Assuming you have a setPassword method
        userRepository.save(user); // Save the updated user back to the database
        return true; // Update successful
    }


    
    public User authenticateUser(String email, String password, UserRole expectedRole) {
        // Fetch the user based on email from the database
        User user = userRepository.findByEmail(email);
        
        // Check if the user exists
        if (user == null) {
            throw new IllegalArgumentException("Invalid email or password.");
        }
 
        // Check if the password matches (ensure password is hashed and compared securely)
        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Invalid email or password.");
        }
 
        // Check if the user's role matches the expected role
        if (!user.getRole().equals(expectedRole)) {
            throw new IllegalArgumentException("Access denied. Incorrect role.");
        }
 
        return user;
    }
    
    public User authenticateAdmin(String email, String password) {
        // Fetch the user based on email from the database
        User user = userRepository.findByEmail(email);
        
        // Check if the user exists
        if (user == null) {
            throw new IllegalArgumentException("Invalid email or password.");
        }
 
        // Check if the password matches (ensure password is hashed and compared securely)
        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Invalid email or password.");
        }
 
        // Check if the user's role is ADMIN
        if (!user.getRole().equals(UserRole.ADMIN)) {
            throw new IllegalArgumentException("Access denied. Admin role required.");
        }
 
        return user;
    }
    
    public User registerAdmin(User user) {
        // Set the role to ADMIN
        user.setRole(UserRole.ADMIN);
        return userRepository.save(user);
    }

   
    public List<User> findByName(String name) {
        return userRepository.findByName(name);
    }


	


}
