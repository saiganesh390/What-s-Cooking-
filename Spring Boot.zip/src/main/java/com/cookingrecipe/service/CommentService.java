package com.cookingrecipe.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cookingrecipe.model.Comment;
import com.cookingrecipe.model.Recipe;
import com.cookingrecipe.model.User;
import com.cookingrecipe.repository.CommentRepository;
import com.cookingrecipe.repository.RecipeRepository;
import com.cookingrecipe.repository.UserRepository;

@Service
public class CommentService {
    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private RecipeRepository recipeRepository;

    @Autowired
    private UserRepository userRepository;

    public Comment saveComment(Comment comment) {
        Recipe recipe = recipeRepository.findById(comment.getRecipe().getId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid recipe ID"));
        User user = userRepository.findById(comment.getUser().getId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID"));
        comment.setRecipe(recipe);
        comment.setUser(user);
        return commentRepository.save(comment);
    }
}
