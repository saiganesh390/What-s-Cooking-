package com.cookingrecipe.model;

public enum UserRole {
    ADMIN,
    USER
}
