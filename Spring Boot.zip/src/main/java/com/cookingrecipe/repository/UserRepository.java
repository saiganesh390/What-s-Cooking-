package com.cookingrecipe.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cookingrecipe.model.User;
import com.cookingrecipe.model.UserRole;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
    User findByEmailAndPassword(String email, String password);
    
	User findByEmailAndPasswordAndRole(String email, String password, UserRole role);
	 List<User> findByName(String name);
}
