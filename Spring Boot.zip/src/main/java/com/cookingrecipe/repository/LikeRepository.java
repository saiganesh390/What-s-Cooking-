package com.cookingrecipe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cookingrecipe.model.Like;

public interface LikeRepository extends JpaRepository<Like, Long> {
}
