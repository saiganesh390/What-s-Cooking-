package com.cookingrecipe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookingrecipeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CookingrecipeApplication.class, args);
	}

}
