import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { LoginComponent } from './user/login/login.component';
import { ProfileComponent } from './user/profile/profile.component';
import { SearchRecipesComponent } from './user/search-recipes/search-recipes.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { RecipeDetailsComponent } from './admin/recipe-details/recipe-details.component';
import { EditRecipeComponent } from './admin/edit-recipe/edit-recipe.component';
import { LogoutComponent } from './user/logout/logout.component';
import { AddRecipeComponent } from './admin/add-recipe/add-recipe.component';
import { DetailsRecipeComponent } from './user/details-recipe/details-recipe.component';
import { ContactUsComponent } from './shared/contact-us/contact-us.component';
import { AdminRegisterComponent } from './admin/Admin-Register/admin-register.component';
import { ForgotPasswordComponent } from './user/forgot-password/forgot-password.component';
import { EndorsedComponent } from './user/endorsed/endorsed.component';

const routes: Routes = [
   { path: '', component: LoginComponent }, // Default route
   { path: 'register', component: RegistrationComponent },
   { path: 'login', component: LoginComponent },
   { path: 'home', component: HomeComponent },
   { path: 'forgot-password', component: ForgotPasswordComponent },
   { path: 'contact', component: ContactUsComponent },
   { path: 'search-recipes', component: SearchRecipesComponent },
   { path: 'Endorserd-recipes', component: EndorsedComponent },

   { path: 'user/logout', component: LogoutComponent },
   { path: 'add-recipe', component: AddRecipeComponent },
   { path: 'admin-register', component: AdminRegisterComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'admin/dashboard', component: AdminDashboardComponent },
  { path: 'admin/recipes/:id', component: RecipeDetailsComponent },
  { path: 'admin/recipes/edit/:id', component: EditRecipeComponent },
  { path: 'admin/register', component: AdminRegisterComponent },
  { path: 'user/register', component: RegistrationComponent },
  { path: 'user/login', component: LoginComponent },
  { path: 'user/profile', component: ProfileComponent },
  { path: 'user/search-recipes', component: SearchRecipesComponent },
  { path: 'user/details-recipe/:id', component: DetailsRecipeComponent },
    { path: '**', redirectTo: '' } // Redirect any unknown routes to home
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
