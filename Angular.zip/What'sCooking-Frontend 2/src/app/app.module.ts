import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { LoginComponent } from './user/login/login.component';
import { ProfileComponent } from './user/profile/profile.component';
import { SearchRecipesComponent } from './user/search-recipes/search-recipes.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { AuthService } from './services/auth.service';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { RecipeDetailsComponent } from './admin/recipe-details/recipe-details.component';
import { EditRecipeComponent } from './admin/edit-recipe/edit-recipe.component';
import { LogoutComponent } from './user/logout/logout.component';
import { AddRecipeComponent } from './admin/add-recipe/add-recipe.component';
import { DetailsRecipeComponent } from './user/details-recipe/details-recipe.component';
import { ContactUsComponent } from './shared/contact-us/contact-us.component';
import { AdminRegisterComponent } from './admin/Admin-Register/admin-register.component';
import { ForgotPasswordComponent } from './user/forgot-password/forgot-password.component';
import { EndorsedComponent } from './user/endorsed/endorsed.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    RegistrationComponent,
    LoginComponent,
    ProfileComponent,
    SearchRecipesComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AdminDashboardComponent,
    RecipeDetailsComponent,
    EditRecipeComponent,
    LogoutComponent,
    AddRecipeComponent,
    DetailsRecipeComponent,
    ContactUsComponent,
    AdminRegisterComponent,
    ForgotPasswordComponent,
    EndorsedComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
