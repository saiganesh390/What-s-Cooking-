import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private name: string = '';
  private email: string = '';

  setUserDetails(name: string, email: string) {
    this.name = name;
    this.email = email;
  }

  getName(): string {
    return this.name;
  }

  getEmail(): string {
    return this.email;
  }

  clearUserDetails() {
    this.name = '';
    this.email = '';
  }
}
