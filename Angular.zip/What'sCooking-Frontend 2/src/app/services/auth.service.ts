import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { Router } from '@angular/router'; 
import { User } from '../user.model';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  private email: string | null = null;
  private name: string | null = null;

  
  setEmail(email: string): void {
    this.email = email;
  }
  setName(name: string): void {
    this.name = name;
    localStorage.setItem('userName', name); 
  }
  
  getName(): string | null {
    return this.name || localStorage.getItem('userName'); 
  }
  getEmail(): string | null {
    return this.email;
  }

  getUserId(): number | null {
   
    return 1; 
  }
  
  private baseUrl ="http://localhost:8222/api/accounts"
  constructor(private http: HttpClient,private router:Router) {}
        // User Login
  register(name:string,email: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, {name, email, password });
  }

  userLogin(credentials: { email: string, password: string }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/login`, credentials);
  }
  
      //Admin
  adminLogin(credentials: { email: string, password: string, role: string }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/admin/login`, credentials);
  }

  registerAdmin(name: string, email: string, password: string) {
    return this.http.post(`${this.baseUrl}/register/admin`, { name, email, password });
  }

    //Forgot-Password
  updatePassword(email: string, newPassword: string): Observable<string> {
    return this.http.put<string>(`${this.baseUrl}/update-password`, {
      email,
      newPassword,
      confirmPassword: newPassword 
    });
  }
    //Profile
  getProfile(name: string): Observable<User[]> { 
    return this.http.get<User[]>(`${this.baseUrl}/find?name=${name}`); 
  }
  
  
}
