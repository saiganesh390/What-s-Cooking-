import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../user.model';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private baseUrl = 'http://localhost:8222/api/accounts'; // Adjust as necessary

  constructor(private http: HttpClient) {}

  getProfile(name: string): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/find?name=${name}`);
  }

  // You can also add methods to get the name, if stored locally or through a different endpoint.
}
