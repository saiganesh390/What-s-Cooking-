import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Like } from '../user/like.model';


@Injectable({
  providedIn: 'root'
})
export class LikeService {
  private apiUrl = 'http://localhost:8222/api/likes';

  constructor(private http: HttpClient) {}

  addLike(like: Like): Observable<Like> {
    return this.http.post<Like>(this.apiUrl, like);
  }
}
