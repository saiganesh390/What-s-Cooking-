import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private apiUrl = 'http://localhost:8222/api/accounts/register'; // Adjust URL as needed
  name: string = '';

  constructor(private http: HttpClient, private router: Router, private authService: AuthService) {}

  ngOnInit() {
    this.name = this.authService.getName()!; // Store the name in the component property
  }

  onSubmit(form: NgForm) {
    if (form.valid) {
      const formData = {
        name: form.value.name,
        email: form.value.email,
        password: form.value.password
        // The role is set on the backend, so we don't need to send it from the frontend
      };

      this.http.post(this.apiUrl, formData)
        .subscribe(
          response => {
            console.log('Success:', response);
            alert('Registration successful!');
            this.router.navigate(['/user/login']); // Navigate to login page after successful registration
          },
          error => {
            console.error('Error:', error);
            alert('Registration failed!');
          }
        );
    } else {
      alert('Please fill out all required fields.');
    }
  }
}
