import { Component } from '@angular/core';

interface Recipe {
  id: number;
  name: string;
  image: string;
  category: string; // Retain only the category property
}

@Component({
  selector: 'app-endorsed',
  templateUrl: './endorsed.component.html',
  styleUrls: ['./endorsed.component.css']
})
export class EndorsedComponent {
  recipes: Recipe[] = [
    { id: 1, name: 'Quinoa Salad with Lemon Dressing', image: 'https://tse4.mm.bing.net/th/id/OIP.IS1vSoTuV0QwhT8NpTm17QHaIt?rs=1&pid=ImgDetMain', category: 'Salads' },
    { id: 2, name: 'Grilled Salmon with Avocado Salsa', image: 'https://tse3.mm.bing.net/th/id/OIP.nt4t0QxnptxrrY7v3a_YlwHaJQ?rs=1&pid=ImgDetMain', category: 'Salads' },
    { id: 3, name: 'Roasted Beet and Goat Cheese Salad', image: 'https://www.jessicagavin.com/wp-content/uploads/2017/11/roasted-beet-salad-with-goat-cheese-pin2.jpg', category: 'Salads' },
    { id: 4, name: 'Shrimp and Avocado Salad', image: 'https://tse3.mm.bing.net/th/id/OIP.lGxkI2kZOzcFFbJUfkXCdAHaLH?rs=1&pid=ImgDetMain', category: 'Salads' },
    { id: 5, name: 'Kale and Quinoa Power Bowl', image: 'https://www.fitmittenkitchen.com/wp-content/uploads/2021/06/Southwest-Quinoa-Power-Bowl-11-683x1024.jpg', category: 'Bowls' },
    { id: 6, name: 'Vegan Buddha Bowl with Tofu and Tahini Dressing', image: 'https://www.wellplated.com/wp-content/uploads/2016/04/Buddha-Bowl-with-Quinoa.jpg', category: 'Bowls' },
    { id: 7, name: 'Chia Pudding with Almond Milk and Berries', image: 'https://tse1.mm.bing.net/th/id/OIP.30q3n5MTaBrSAVFby7VGjgHaKK?rs=1&pid=ImgDetMain', category: 'Bowls' },
    { id: 8, name: 'Roasted Sweet Potato and Black Bean Tacos', image: 'https://www.gimmesomeoven.com/wp-content/uploads/2020/04/Roasted-Sweet-Potato-Tacos-Recipe-2.jpg', category: 'Tacos & Wraps' },
    { id: 9, name: 'Stuffed Bell Peppers with Quinoa and Turkey', image: 'https://www.jessicagavin.com/wp-content/uploads/2016/08/mexican-spiced-quinoa-with-turkey-stuffed-in-roasted-peppers-600x900.jpg', category: 'Tacos & Wraps' },
    { id: 10, name: 'Zucchini Noodles with Pesto and Cherry Tomatoes', image: 'https://www.theendlessmeal.com/wp-content/uploads/2015/10/pesto-zucchini-noodles-2.jpg', category: 'Pasta & Noodles' },
    { id: 11, name: 'Soba Noodle Salad with Sesame Dressing', image: 'https://i.pinimg.com/originals/3a/7d/17/3a7d1731834410c8cbdcb6f6d9d746e6.jpg', category: 'Pasta & Noodles' },
    { id: 12, name: 'Spaghetti Squash with Marinara Sauce', image: 'https://i.pinimg.com/originals/97/15/c9/9715c9f9e68fe4e797defd2bf072281c.jpg', category: 'Pasta & Noodles' },
    { id: 13, name: 'Spinach and Feta Stuffed Chicken Breasts', image: 'https://tse1.mm.bing.net/th/id/OIP.QbFF8VLP3EgLU2CXlQ5wIQHaLH?w=198&h=297&c=7&r=0&o=5&pid=1.7', category: 'Main Dishes' },
    { id: 14, name: 'Baked Cod with Garlic and Herb Crust', image: 'https://cookingwithcarlee.com/wp-content/uploads/2020/01/looking2Bdown2Bon2Bfeta2Bspinach2Bstuffed2Bchicken.jpg', category: 'Main Dishes' },
    { id: 15, name: 'Coconut Curry Chicken with Vegetables', image: 'https://shuangyskitchensink.com/wp-content/uploads/2019/01/Thai-Coconut-Curry-Chicken-5-1229x1536.jpg', category: 'Main Dishes' },
    { id: 16, name: 'Grilled Portobello Mushroom Burger', image: 'https://tse2.mm.bing.net/th/id/OIP.L2RiNqUamaLqQ6XjRl79HwHaKX?rs=1&pid=ImgDetMain', category: 'Main Dishes' },
    { id: 17, name: 'Turkey and Zucchini Meatballs', image: 'https://tse1.mm.bing.net/th/id/OIP.0w_0_QdGH9LeBHmAsBkkqAHaKv?rs=1&pid=ImgDetMain', category: 'Main Dishes' },
    { id: 18, name: 'Chickpea and Spinach Curry', image: 'https://tse3.mm.bing.net/th/id/OIP.VrsF1lWGtrKCTUEjjb5dqAHaLH?rs=1&pid=ImgDetMain', category: 'Main Dishes' },
    { id: 19, name: 'Lentil and Vegetable Stew', image: 'https://tse2.mm.bing.net/th/id/OIP.PndyKFzGTs7PVtoES-2knwHaLH?rs=1&pid=ImgDetMain', category: 'Soups & Stews' },
    { id: 20, name: 'Butternut Squash Soup with Coconut Milk', image: 'https://www.wellplated.com/wp-content/uploads/2018/11/Slow-Cooker-Butternut-Squash-Apple-Soup.jpg', category: 'Soups & Stews' },
    { id: 21, name: 'Oven-Baked Sweet Potato Fries', image: 'https://tse4.mm.bing.net/th/id/OIP.rnF1J-8uLgxAPnyDv0WoVwHaLF?rs=1&pid=ImgDetMain', category: 'Sides' },
    { id: 22, name: 'Roasted Brussels Sprouts with Balsamic Glaze', image: 'https://lemonsandzest.com/wp-content/uploads/2020/10/Roasted-Brussels-Sprouts-with-Balsamic-6-1092x1536.jpg', category: 'Sides' },
    { id: 23, name: 'Avocado and Egg Toast', image: 'https://tse2.mm.bing.net/th/id/OIP.PbN_TNrwrB-QTN6ZMaOVgQAAAA?rs=1&pid=ImgDetMain', category: 'Breakfast' },
    { id: 24, name: 'Greek Yogurt Parfait with Berries and Honey', image: 'https://tse1.mm.bing.net/th/id/OIP.imnWVeVTS6ip5KM5Prp1swHaJ4?w=720&h=960&rs=1&pid=ImgDetMain', category: 'Breakfast' },
    { id: 25, name: 'Berry Smoothie Bowl with Chia Seeds and Almond Butter', image: 'https://aromaticessence.co/wp-content/uploads/2018/07/BE19BE4A-ABDC-463C-8C81-D7C96DE9D7A4.jpeg', category: 'Breakfast' },
    { id: 26, name: 'Baked Falafel with Tzatziki Sauce', image: 'https://img.buzzfeed.com/thumbnailer-prod-us-east-1/974297a311bb4f6eb04020524ad2c193/BFV37212_FalafelTwoWays_TastyVeg_v4_1.jpg', category: 'Snacks' },
    { id: 27, name: 'Cauliflower Crust Pizza', image: 'https://sunkissedkitchen.com/wp-content/uploads/2019/06/cauliflower-crust-veggie-toppings.jpg', category: 'Snacks' },
  ];

  filteredRecipes: Recipe[] = this.recipes; // Initialize with all recipes
  searchTerm: string = '';

  searchRecipes() {
    this.filteredRecipes = this.recipes.filter(recipe =>
      recipe.name.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  filterByCategory(category: string) {
    this.filteredRecipes = this.recipes.filter(recipe =>
      recipe.category === category
    );
  }
}
