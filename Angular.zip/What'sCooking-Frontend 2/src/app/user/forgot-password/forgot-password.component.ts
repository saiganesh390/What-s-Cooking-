import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {
  forgotPasswordForm: FormGroup;
  message: string = '';
  isLoading: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private fb: FormBuilder
  ) {
    this.forgotPasswordForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      newPassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]]
    });
  }

  onSubmit() {
    if (this.forgotPasswordForm.invalid) {
      this.message = 'Please fill in all fields correctly.';
      return;
    }

    const { email, newPassword, confirmPassword } = this.forgotPasswordForm.value;

    if (newPassword !== confirmPassword) {
      this.message = 'Passwords do not match.';
      return;
    }

    this.isLoading = true;
    this.authService.updatePassword(email, newPassword)
      .subscribe({
        next: () => {
          this.message = 'Password updated successfully!';
          this.router.navigate(['/']);
        },
        error: (err) => {
          this.message = 'Error updating password: ' + (err.error?.message || err.message);
        },
        complete: () => this.isLoading = false
      });
  }
}
