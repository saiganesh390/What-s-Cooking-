import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { User } from 'src/app/user.model';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: User[] | undefined; // Change from User to User[]
  isLoading = false;
  errorMessage: string | null = null;

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.getUserProfile();
  }
  
  getUserProfile(): void {
    const name = this.authService.getName();
    console.log('Retrieved name:', name);
  
    if (name) {
      this.isLoading = true;
      console.log('Fetching profile for:', name); // Debug log
  
      this.authService.getProfile(name).subscribe(
        (data) => {
          console.log('Profile data received:', data); // Log the received data
          this.user = data; // Expecting data to be an array of User
          this.isLoading = false;
        },
        (error) => {
          console.error('Error fetching user profile', error);
          this.errorMessage = 'Failed to load profile. Please try again later.';
          this.isLoading = false;
        }
      );
    } else {
      console.error('No name found');
      this.errorMessage = 'No name found. Please log in again.';
    }
  }
}
