export interface Comment {
    id?: number;
    recipe: { id: number };
    user: { id: number };
    text: string;
  }