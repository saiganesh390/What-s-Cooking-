export interface Like {
    id?: number;
    recipe: { id: number };
    user: { id: number };
  }
  