import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-register',
  templateUrl: './admin-register.component.html',
  styleUrls: ['./admin-register.component.css']
})
export class AdminRegisterComponent {
  adminRegisterForm: FormGroup;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
    
  ) {
    this.adminRegisterForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@gmail\.com$/)]],
      password: ['', [Validators.required, Validators.pattern(/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)]]
    });
  }

  registerAdmin() {
    if (this.adminRegisterForm.valid) {
      const { name, email, password } = this.adminRegisterForm.value;

      this.authService.registerAdmin(name, email, password).subscribe(
        response => {
          console.log('Admin account created', response);
          this.router.navigate(['/admin-login']);
          
        },
        error => {
          console.error('Account creation failed', error);
          this.errorMessage = 'Admin account creation failed. Please check your details and try again.';
        }
      );
    } else {
      this.adminRegisterForm.markAllAsTouched();
    }
  }
}
