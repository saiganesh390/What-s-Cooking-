import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RecipeService } from 'src/app/services/recipe.service';

@Component({
  selector: 'app-add-recipe',
  templateUrl: './add-recipe.component.html',
  styleUrls: ['./add-recipe.component.css']
})
export class AddRecipeComponent {
  recipeForm: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private recipeService: RecipeService,
    private router: Router
  ) {
    this.recipeForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      ingredients: ['', Validators.required],
      cookingSteps: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.recipeForm.valid) {
      this.recipeService.createRecipe(this.recipeForm.value).subscribe({
        next: (response) => {
          this.router.navigate(['/admin/dashboard']);
        },
        error: (error) => {
          this.errorMessage = 'Failed to create recipe. Please try again.';
        }
      });
    }
  }
}
