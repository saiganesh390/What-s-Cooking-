import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { RecipeService } from 'src/app/services/recipe.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  recipes: any[] = [];
  errorMessage: string | null = null;

  private apiUrl = 'http://localhost:8222/api/recipes';

  constructor(private recipeService: RecipeService, private router: Router) {}

  private imageUrlMapping: { [key: number]: string } = {
    1: 'https://b.zmtcdn.com/data/pictures/chains/2/20894732/60dd668b70a8b8916a699b1456566218.jpg',
    2:'https://www.thespruceeats.com/thmb/3aS-MqMydQjW1n7RBGWNVYQagIo=/4494x3000/filters:fill(auto,1)/basic-turkish-chicken-kebab-3274263_19-5b4ce87746e0fb00370a5025.jpg',
    3:'https://freshprotino.com/wp-content/uploads/2021/03/maxresdefault-1.jpg',
    4:'https://www.archanaskitchen.com/images/archanaskitchen/1-Author/priyanjali/shutterstock_111998606.jpg',
    12:'https://www.wikihow.com/images/a/a8/Make-Hyderabadi-Vegetable-Biryani-Step-15.jpg',
    13:'https://www.thespruceeats.com/thmb/pO_MrO2DBC8RZXrbFbgd4lQs4V4=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/south-indian-tangy-tomato-rice-1957729-9b96340e3d274f12a12456cce154ff57.jpg',
    14:'https://www.foodie-trail.com/wp-content/uploads/2020/10/20201016_182146719_iOS-scaled.jpg',
    15:'https://foodiewish.com/wp-content/uploads/2020/07/Gazar-Ka-Halwa-758x583.jpg',
    16:'https://www.vegrecipesofindia.com/wp-content/uploads/2021/01/methi-thepla.jpg',
    17:'https://vaya.in/recipes/wp-content/uploads/2018/03/Fish-Tikka.jpg',
    18:'https://tse1.mm.bing.net/th/id/OIP.5W3v5UNiezZxyQQ9qB0H7wHaLC?rs=1&pid=ImgDetMain',
    19:'https://d36v5spmfzyapc.cloudfront.net/wp-content/uploads/2021/01/south-indian-curd-rice-2.jpg',
    20:'https://www.healthifyme.com/blog/wp-content/uploads/2018/03/idly2.jpeg',
    21:'https://global-uploads.webflow.com/5ec64dd010abbf1a7cd39650/607d1585074cd31b66965728_wp6734909_ff389ec945d7ef040f982b9ff5a5b35a_2000.jpeg',
    22:'https://i.pinimg.com/originals/94/8f/9b/948f9beaddc6c09fb977c2660780fb2c.jpg',
    23:'https://tse3.mm.bing.net/th/id/OIP.Dv9TvB3k5OhbpDItk1ny3AHaLH?rs=1&pid=ImgDetMain',
    24:'https://www.thestatesman.com/wp-content/uploads/2019/07/pav-bhaji.jpg',
    25:'https://www.foodandwine.com/thmb/gv06VNqj1uUJHGlw5e7IULwUmr8=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/2012-r-xl-vegetable-sandwich-with-dill-sauce-2000-0984c1b513ae4af396aee039afa5e38c.jpg',
    26:'https://tse4.mm.bing.net/th/id/OIP.4tb8yoSwDWOdyQJADBhR5wHaLk?rs=1&pid=ImgDetMain',
    27:'https://www.kitchensanctuary.com/wp-content/uploads/2021/03/Egg-fried-rice-tall-FS-37.jpg'
  };

  ngOnInit(): void {
    this.loadRecipes();
  }
  
  loadRecipes(): void {
    this.recipeService.getAllRecipes()
      .subscribe({
        next: (data) => {
          this.recipes = data.map(recipe => ({
            ...recipe,
            photo: this.imageUrlMapping[recipe.id] || 'default_image_url'  
          }));
          console.log('Recipes loaded:', this.recipes);
        },
        error: (error) => {
          console.error('Error loading recipes:', error);
          this.errorMessage = 'Failed to load recipes. Please try again later.';
        }
      });
  }
  searchRecipes(query: string): void {
    if (query) {
      this.recipeService.searchRecipes(query)
        .subscribe({
          next: (data) => {
            this.recipes = data.map(recipe => ({
              ...recipe,
              photo: this.imageUrlMapping[recipe.id] || 'https://via.placeholder.com/150'  
            }));
            console.log('Search results:', this.recipes);
          },
          error: (error) => {
            console.error('Error searching recipes:', error);
            this.errorMessage = 'Failed to search recipes. Please try again later.';
          }
        });
    } else {
      this.loadRecipes();
    }
  }
  onSearch(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    const query = inputElement.value;
    this.searchRecipes(query);
  }


  viewRecipeDetails(id: number): void {
    this.router.navigate([`/admin/recipes/${id}`]);
  }
}
