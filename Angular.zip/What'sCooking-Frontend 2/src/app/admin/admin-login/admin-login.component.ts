import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {
  loginForm: FormGroup;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router // Inject Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
      // Remove role field from the form group
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const loginRequest = this.loginForm.value;

      this.http.post('http://localhost:8222/api/accounts/admin/login', loginRequest)
        .subscribe({
          next: (response: any) => {
            console.log('Login successful:', response);
            // Navigate to admin dashboard
            this.router.navigate(['/admin/dashboard']); // Adjust path as needed
          },
          error: (error) => {
            console.error('Login failed:', error);
            this.errorMessage = 'Login failed. Please check your credentials and try again.';
          }
        });
    }
  }
}
