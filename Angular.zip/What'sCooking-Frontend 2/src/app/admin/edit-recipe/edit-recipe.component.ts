import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-edit-recipe',
  templateUrl: './edit-recipe.component.html',
  styleUrls: ['./edit-recipe.component.css']
})
export class EditRecipeComponent implements OnInit {
  recipeForm: FormGroup;
  recipeId: number | null = null;
  errorMessage: string | null = null;
  private apiUrl = 'http://localhost:8222/api/recipes';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {
    this.recipeForm = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      ingredients: [''],
      cookingSteps: [''],
      picture: ['']
    });
  }

  ngOnInit(): void {
    this.recipeId = +this.route.snapshot.paramMap.get('id')!;
    if (this.recipeId) {
      this.loadRecipe();
    }
  }

  loadRecipe(): void {
    this.http.get<any>(`${this.apiUrl}/${this.recipeId}`)
      .subscribe({
        next: (data) => {
          this.recipeForm.patchValue(data);
        },
        error: (error) => {
          console.error('Error loading recipe details:', error);
          this.errorMessage = 'Failed to load recipe details. Please try again later.';
        }
      });
  }

  onSubmit(): void {
    if (this.recipeForm.valid && this.recipeId) {
      const updatedRecipe = this.recipeForm.value;

      this.http.put<any>(`${this.apiUrl}/${this.recipeId}`, updatedRecipe)
        .subscribe({
          next: (data) => {
            alert('Recipe updated successfully!');
            this.router.navigate(['/admin/dashboard']);
          },
          error: (error) => {
            console.error('Error updating recipe:', error);
            this.errorMessage = 'Failed to update recipe. Please try again later.';
          }
        });
    }
  }
}
